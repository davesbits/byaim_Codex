Shared assets (env.<site>.js, init-auth.js) are served from this folder.
